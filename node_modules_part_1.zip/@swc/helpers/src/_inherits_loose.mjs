export { _ as default } from "../esm/_inherits_loose.js";
