export { _ as default } from "../esm/_await_value.js";
