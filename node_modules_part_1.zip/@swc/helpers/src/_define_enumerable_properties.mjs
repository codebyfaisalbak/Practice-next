export { _ as default } from "../esm/_define_enumerable_properties.js";
