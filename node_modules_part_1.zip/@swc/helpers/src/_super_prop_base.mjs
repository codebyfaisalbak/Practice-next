export { _ as default } from "../esm/_super_prop_base.js";
