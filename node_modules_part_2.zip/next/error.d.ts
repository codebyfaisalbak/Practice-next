import Error from './dist/pages/_error'
export * from './dist/pages/_error'
export default Error
