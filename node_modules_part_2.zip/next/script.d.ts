import Script from './dist/client/script'
export * from './dist/client/script'
export default Script
