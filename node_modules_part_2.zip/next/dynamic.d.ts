import dynamic from './dist/shared/lib/dynamic'
export * from './dist/shared/lib/dynamic'
export default dynamic
